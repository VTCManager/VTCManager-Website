// Copied from: https://github.com/mike-koch/ets2-mobile-route-advisor/blob/5bde032121cbabac3bfd98f156a1e376d9903fd8/js/cities.js

var g_cities_json = [
	{
		"gameName": "aberdeen",
		"realName": "Aberdeen",
		"country": "uk",
		"x": "-38846.7",
		"y": "144",
		"z": "-55270.3"
	},
	{
		"gameName": "amsterdam",
		"realName": "Amsterdam",
		"country": "netherlands",
		"x": "-18598.7",
		"y": "105.766",
		"z": "-11736.2"
	},
	{
		"gameName": "berlin",
		"realName": "Berlin",
		"country": "germany",
		"x": "10343",
		"y": "79.8828",
		"z": "-9903.56"
	},
	{
		"gameName": "bern",
		"realName": "Bern",
		"country": "switzerland",
		"x": "-12730.8",
		"y": "101.68",
		"z": "20130.1"
	},
	{
		"gameName": "birmingham",
		"realName": "Birmingham",
		"country": "uk",
		"x": "-45951.1",
		"y": "109.57",
		"z": "-20423"
	},
	{
		"gameName": "bratislava",
		"realName": "Bratislava",
		"country": "slovakia",
		"x": "24823.3",
		"y": "77.1289",
		"z": "14831"
	},
	{
		"gameName": "bremen",
		"realName": "Bremen",
		"country": "germany",
		"x": "-4919.98",
		"y": "75.2969",
		"z": "-14099.2"
	},
	{
		"gameName": "brno",
		"realName": "Brno",
		"country": "czech",
		"x": "22273.8",
		"y": "64.8086",
		"z": "8964.95"
	},
	{
		"gameName": "brussel",
		"realName": "Brussel",
		"country": "belgium",
		"x": "-21576",
		"y": "99.3594",
		"z": "-3235.03"
	},
	{
		"gameName": "calais",
		"realName": "Calais",
		"country": "france",
		"x": "-30243",
		"y": "92.2344",
		"z": "-4985.64"
	},
	{
		"gameName": "cambridge",
		"realName": "Cambridge",
		"country": "uk",
		"x": "-36822.7",
		"y": "171.199",
		"z": "-16119.4"
	},
	{
		"gameName": "cardiff",
		"realName": "Cardiff",
		"country": "uk",
		"x": "-54005.3",
		"y": "171.398",
		"z": "-14698.4"
	},
	{
		"gameName": "carlisle",
		"realName": "Carlisle",
		"country": "uk",
		"x": "-45889.2",
		"y": "153",
		"z": "-39573.5"
	},
	{
		"gameName": "dijon",
		"realName": "Dijon",
		"country": "france",
		"x": "-22312",
		"y": "97.3984",
		"z": "16721.5"
	},
	{
		"gameName": "dortmund",
		"realName": "Dortmund",
		"country": "germany",
		"x": "-10270.5",
		"y": "110",
		"z": "-5598.41"
	},
	{
		"gameName": "dover",
		"realName": "Dover",
		"country": "uk",
		"x": "-33321.9",
		"y": "99.3984",
		"z": "-7884.36"
	},
	{
		"gameName": "dresden",
		"realName": "Dresden",
		"country": "germany",
		"x": "12411.8",
		"y": "101.914",
		"z": "-1606.27"
	},
	{
		"gameName": "duisburg",
		"realName": "Duisburg",
		"country": "germany",
		"x": "-12913.6",
		"y": "50",
		"z": "-6170.93"
	},
	{
		"gameName": "dusseldorf",
		"realName": "Düsseldorf",
		"country": "germany",
		"x": "-13377.2",
		"y": "97.9297",
		"z": "-4399.6"
	},
	{
		"gameName": "edinburgh",
		"realName": "Edinburgh",
		"country": "uk",
		"x": "-44900.7",
		"y": "139",
		"z": "-47219.7"
	},
	{
		"gameName": "erfurt",
		"realName": "Erfurt",
		"country": "germany",
		"x": "2436.19",
		"y": "101.914",
		"z": "-1733.77"
	},
	{
		"gameName": "europoort",
		"realName": "Europoort",
		"country": "netherlands",
		"x": "-21791.1",
		"y": "78.5234",
		"z": "-8987.42"
	},
	{
		"gameName": "felixstowe",
		"realName": "Felixstowe",
		"country": "uk",
		"x": "-31664.6",
		"y": "101.398",
		"z": "-13837.2"
	},
	{
		"gameName": "frankfurt",
		"realName": "Frankfurt am Main",
		"country": "germany",
		"x": "-6112.34",
		"y": "99.1875",
		"z": "2633.59"
	},
	{
		"gameName": "geneve",
		"realName": "Genève",
		"country": "switzerland",
		"x": "-18099.1",
		"y": "101.68",
		"z": "23717"
	},
	{
		"gameName": "glasgow",
		"realName": "Glasgow",
		"country": "uk",
		"x": "-50384.7",
		"y": "139",
		"z": "-48471.6"
	},
	{
		"gameName": "graz",
		"realName": "Graz",
		"country": "austria",
		"x": "18216.5",
		"y": "83.0938",
		"z": "20552.7"
	},
	{
		"gameName": "grimsby",
		"realName": "Grimsby",
		"country": "uk",
		"x": "-36117.9",
		"y": "124.66",
		"z": "-26575.2"
	},
	{
		"gameName": "groningen",
		"realName": "Groningen",
		"country": "netherlands",
		"x": "-12437.6",
		"y": "68.8711",
		"z": "-15468.7"
	},
	{
		"gameName": "hamburg",
		"realName": "Hamburg",
		"country": "germany",
		"x": "83.6914",
		"y": "45.7227",
		"z": "-16704.2"
	},
	{
		"gameName": "hannover",
		"realName": "Hannover",
		"country": "germany",
		"x": "-1928.93",
		"y": "77.8242",
		"z": "-8916.4"
	},
	{
		"gameName": "hull",
		"realName": "Hull",
		"country": "uk",
		"x": "-35543.9",
		"y": "121.809",
		"z": "-29239.1"
	},
	{
		"gameName": "ijmuiden",
		"realName": "IJmuiden",
		"country": "netherlands",
		"x": "-19700.3",
		"y": "75.3477",
		"z": "-12077.1"
	},
	{
		"gameName": "innsbruck",
		"realName": "Innsbruck",
		"country": "austria",
		"x": "2250.09",
		"y": "67.0859",
		"z": "19214.1"
	},
	{
		"gameName": "kassel",
		"realName": "Kassel",
		"country": "germany",
		"x": "-3031.32",
		"y": "85.293",
		"z": "-3898.7"
	},
	{
		"gameName": "kiel",
		"realName": "Kiel",
		"country": "germany",
		"x": "188.074",
		"y": "55.832",
		"z": "-20826.7"
	},
	{
		"gameName": "klagenfurt",
		"realName": "Klagenfurt am Wörthersee",
		"country": "austria",
		"x": "14001.3",
		"y": "49.6523",
		"z": "23027.6"
	},
	{
		"gameName": "koln",
		"realName": "Köln",
		"country": "germany",
		"x": "-13150.8",
		"y": "97.9297",
		"z": "-2732.75"
	},
	{
		"gameName": "leipzig",
		"realName": "Leipzig",
		"country": "germany",
		"x": "7042.06",
		"y": "101.914",
		"z": "-3160.18"
	},
	{
		"gameName": "liege",
		"realName": "Liège",
		"country": "belgium",
		"x": "-17181.5",
		"y": "108.012",
		"z": "-1231.25"
	},
	{
		"gameName": "lille",
		"realName": "Lille",
		"country": "france",
		"x": "-26495.9",
		"y": "92.6211",
		"z": "-2483.4"
	},
	{
		"gameName": "linz",
		"realName": "Linz",
		"country": "austria",
		"x": "13665.7",
		"y": "115.418",
		"z": "13754.6"
	},
	{
		"gameName": "liverpool",
		"realName": "Liverpool",
		"country": "uk",
		"x": "-48871.7",
		"y": "146.066",
		"z": "-29091.8"
	},
	{
		"gameName": "london",
		"realName": "London",
		"country": "uk",
		"x": "-39546.9",
		"y": "171.398",
		"z": "-11564.2"
	},
	{
		"gameName": "luxembourg",
		"realName": "Luxembourg",
		"country": "luxembourg",
		"x": "-16134.2",
		"y": "152.621",
		"z": "4382.97"
	},
	{
		"gameName": "lyon",
		"realName": "Lyon",
		"country": "france",
		"x": "-23869.8",
		"y": "139.359",
		"z": "25892.3"
	},
	{
		"gameName": "magdeburg",
		"realName": "Magdeburg",
		"country": "germany",
		"x": "4484.25",
		"y": "94.7773",
		"z": "-7752.3"
	},
	{
		"gameName": "manchester",
		"realName": "Manchester",
		"country": "uk",
		"x": "-45548.7",
		"y": "108.711",
		"z": "-27815"
	},
	{
		"gameName": "mannheim",
		"realName": "Mannheim",
		"country": "germany",
		"x": "-7722.87",
		"y": "88",
		"z": "6165.95"
	},
	{
		"gameName": "metz",
		"realName": "Metz",
		"country": "france",
		"x": "-16294.5",
		"y": "104.516",
		"z": "7463.71"
	},
	{
		"gameName": "milano",
		"realName": "Milano",
		"country": "italy",
		"x": "-6616.31",
		"y": "100.25",
		"z": "28982.8"
	},
	{
		"gameName": "munchen",
		"realName": "München",
		"country": "germany",
		"x": "3187.57",
		"y": "83.375",
		"z": "14128.9"
	},
	{
		"gameName": "newcastle",
		"realName": "Newcastle-upon-Tyne",
		"country": "uk",
		"x": "-39778",
		"y": "139",
		"z": "-38787.7"
	},
	{
		"gameName": "nurnberg",
		"realName": "Nürnberg",
		"country": "germany",
		"x": "2665.54",
		"y": "106.301",
		"z": "7237.8"
	},
	{
		"gameName": "osnabruck",
		"realName": "Osnabrück",
		"country": "germany",
		"x": "-7456.28",
		"y": "101.297",
		"z": "-9841.73"
	},
	{
		"gameName": "paris",
		"realName": "Paris",
		"country": "france",
		"x": "-30494.9",
		"y": "92.6211",
		"z": "6998.41"
	},
	{
		"gameName": "plymouth",
		"realName": "Plymouth",
		"country": "uk",
		"x": "-60041.4",
		"y": "101.398",
		"z": "-7882.32"
	},
	{
		"gameName": "poznan",
		"realName": "Poznań",
		"country": "poland",
		"x": "22863.4",
		"y": "46.5508",
		"z": "-9112.2"
	},
	{
		"gameName": "prague",
		"realName": "Praha",
		"country": "czech",
		"x": "14299.7",
		"y": "113.227",
		"z": "3978.97"
	},
	{
		"gameName": "reims",
		"realName": "Reims",
		"country": "france",
		"x": "-24021.9",
		"y": "96.3086",
		"z": "5799.34"
	},
	{
		"gameName": "rostock",
		"realName": "Rostock",
		"country": "germany",
		"x": "6490.95",
		"y": "58.4961",
		"z": "-18588.9"
	},
	{
		"gameName": "rotterdam",
		"realName": "Rotterdam",
		"country": "netherlands",
		"x": "-20156",
		"y": "104.746",
		"z": "-9135.8"
	},
	{
		"gameName": "salzburg",
		"realName": "Salzburg",
		"country": "austria",
		"x": "9075.84",
		"y": "110.809",
		"z": "16564.5"
	},
	{
		"gameName": "sheffield",
		"realName": "Sheffield",
		"country": "uk",
		"x": "-42688.8",
		"y": "103.512",
		"z": "-26687.6"
	},
	{
		"gameName": "southampton",
		"realName": "Southampton",
		"country": "uk",
		"x": "-46338.7",
		"y": "111.398",
		"z": "-7523.25"
	},
	{
		"gameName": "strasbourg",
		"realName": "Strasbourg",
		"country": "france",
		"x": "-10786.9",
		"y": "100",
		"z": "11198.7"
	},
	{
		"gameName": "stuttgart",
		"realName": "Stuttgart",
		"country": "germany",
		"x": "-4957.84",
		"y": "101.973",
		"z": "10047"
	},
	{
		"gameName": "swansea",
		"realName": "Swansea",
		"country": "uk",
		"x": "-56896",
		"y": "71.3984",
		"z": "-16881.9"
	},
	{
		"gameName": "szczecin",
		"realName": "Szczecin",
		"country": "poland",
		"x": "14764.7",
		"y": "96.5508",
		"z": "-15366.7"
	},
	{
		"gameName": "torino",
		"realName": "Torino",
		"country": "italy",
		"x": "-12697.3",
		"y": "89.9023",
		"z": "30932"
	},
	{
		"gameName": "venezia",
		"realName": "Venezia",
		"country": "italy",
		"x": "5089.88",
		"y": "77.8789",
		"z": "30078.9"
	},
	{
		"gameName": "verona",
		"realName": "Verona",
		"country": "italy",
		"x": "39.1094",
		"y": "78.4023",
		"z": "29453.3"
	},
	{
		"gameName": "wien",
		"realName": "Wien",
		"country": "austria",
		"x": "21298.3",
		"y": "114.809",
		"z": "14215.5"
	},
	{
		"gameName": "wroclaw",
		"realName": "Wrocław",
		"country": "poland",
		"x": "23500.3",
		"y": "120.508",
		"z": "-1890.36"
	},
	{
		"gameName": "zurich",
		"realName": "Zürich",
		"country": "switzerland",
		"x": "-8473.81",
		"y": "101.953",
		"z": "17968.5"
	},
	{
		"gameName": "aalborg",
		"realName": "Aalborg",
		"country": "denmark",
		"x": "855.258",
		"y": "46.6875",
		"z": "-35995.1"
	},
	{
		"gameName": "aarhus",
		"realName": "Aarhus",
		"country": "denmark",
		"x": "1808.59",
		"y": "37.4844",
		"z": "-30744.9"
	},
	{
		"gameName": "akranes",
		"realName": "Akranes",
		"country": "iceland",
		"x": "-91465",
		"y": "61.9805",
		"z": "-101511"
	},
	{
		"gameName": "akureyri",
		"realName": "Akureyri",
		"country": "iceland",
		"x": "-77145.7",
		"y": "70.7461",
		"z": "-101575"
	},
	{
		"gameName": "andorra",
		"realName": "Andorra la Vella",
		"country": "andorra",
		"x": "-39815.9",
		"y": "140.875",
		"z": "42009.7"
	},
	{
		"gameName": "angers",
		"realName": "Angers",
		"country": "france",
		"x": "-43531.5",
		"y": "64",
		"z": "12968.1"
	},
	{
		"gameName": "antwerp",
		"realName": "Antwerpen",
		"country": "belgium",
		"x": "-21215.1",
		"y": "82",
		"z": "-5293.52"
	},
	{
		"gameName": "arad",
		"realName": "Arad",
		"country": "romania",
		"x": "41265.9",
		"y": "126.992",
		"z": "24603.7"
	},
	{
		"gameName": "babruysk",
		"realName": "Babruysk",
		"country": "belarus",
		"x": "64394.4",
		"y": "60.5742",
		"z": "-18096.8"
	},
	{
		"gameName": "bacau",
		"realName": "Bacău",
		"country": "romania",
		"x": "62751.6",
		"y": "127.434",
		"z": "20434.6"
	},
	{
		"gameName": "bado",
		"realName": "Bad Oeynhausen",
		"country": "germany",
		"x": "-5724.91",
		"y": "99.8438",
		"z": "-9493.73"
	},
	{
		"gameName": "baiamare",
		"realName": "Baia Mare",
		"country": "romania",
		"x": "49264.7",
		"y": "130",
		"z": "15764.6"
	},
	{
		"gameName": "balti",
		"realName": "Bălţi",
		"country": "moldova",
		"x": "65823.7",
		"y": "120",
		"z": "12512"
	},
	{
		"gameName": "baranovichi",
		"realName": "Baranovichi",
		"country": "belarus",
		"x": "54554.7",
		"y": "64.0586",
		"z": "-16169.5"
	},
	{
		"gameName": "basel",
		"realName": "Basel",
		"country": "switzerland",
		"x": "-11649.5",
		"y": "107.949",
		"z": "17001.7"
	},
	{
		"gameName": "bayonne",
		"realName": "Bayonne",
		"country": "france",
		"x": "-52014.3",
		"y": "64.1016",
		"z": "33499"
	},
	{
		"gameName": "bbiala",
		"realName": "Bielsko-Biała",
		"country": "poland",
		"x": "31289",
		"y": "150.082",
		"z": "5747.38"
	},
	{
		"gameName": "bergen",
		"realName": "Bergen",
		"country": "norway",
		"x": "-10371.6",
		"y": "52.6406",
		"z": "-55777.6"
	},
	{
		"gameName": "blonduos",
		"realName": "Blönduós",
		"country": "iceland",
		"x": "-82233.6",
		"y": "61.9805",
		"z": "-104774"
	},
	{
		"gameName": "bologna",
		"realName": "Bologna",
		"country": "italy",
		"x": "1914.67",
		"y": "80.3516",
		"z": "35291"
	},
	{
		"gameName": "borde",
		"realName": "Bordeaux",
		"country": "france",
		"x": "-47905.3",
		"y": "62",
		"z": "27492.5"
	},
	{
		"gameName": "borgarnes",
		"realName": "Borgarnes",
		"country": "iceland",
		"x": "-89285.6",
		"y": "79.3555",
		"z": "-102462"
	},
	{
		"gameName": "brect",
		"realName": "Brest",
		"country": "belarus",
		"x": "46698.6",
		"y": "103.68",
		"z": "-9542.98"
	},
	{
		"gameName": "bryansk",
		"realName": "Bryansk",
		"country": "russia",
		"x": "82100",
		"y": "61.7188",
		"z": "-22682.4"
	},
	{
		"gameName": "bucuresti",
		"realName": "Bucureşti",
		"country": "romania",
		"x": "61238.3",
		"y": "127.949",
		"z": "32579"
	},
	{
		"gameName": "budapest",
		"realName": "Budapest",
		"country": "hungary",
		"x": "32367.8",
		"y": "123.836",
		"z": "17882.7"
	},
	{
		"gameName": "burg",
		"realName": "Burg a. Fehmarn",
		"country": "germany",
		"x": "4095.55",
		"y": "55.3281",
		"z": "-21142.2"
	},
	{
		"gameName": "bydgoszcz",
		"realName": "Bydgoszcz",
		"country": "poland",
		"x": "26440.3",
		"y": "110.004",
		"z": "-13850.1"
	},
	{
		"gameName": "bystrica",
		"realName": "Banská Bystrica",
		"country": "slovakia",
		"x": "32657.6",
		"y": "100",
		"z": "10680.5"
	},
	{
		"gameName": "caen",
		"realName": "Caen",
		"country": "france",
		"x": "-40904.6",
		"y": "54.5",
		"z": "3042.14"
	},
	{
		"gameName": "calais",
		"realName": "Calais",
		"country": "france",
		"x": "-30243",
		"y": "92.2344",
		"z": "-4985.64"
	},
	{
		"gameName": "carlisle",
		"realName": "Carlisle",
		"country": "uk",
		"x": "-45889.2",
		"y": "153",
		"z": "-39573.5"
	},
	{
		"gameName": "chelmsford",
		"realName": "Chelmsford",
		"country": "uk",
		"x": "-36472.1",
		"y": "98.1016",
		"z": "-12878.6"
	},
	{
		"gameName": "cherb",
		"realName": "Cherbourg",
		"country": "france",
		"x": "-45091.8",
		"y": "52.5352",
		"z": "-447.961"
	},
	{
		"gameName": "chisinau",
		"realName": "Chişinău",
		"country": "moldova",
		"x": "70134.7",
		"y": "120",
		"z": "16235.3"
	},
	{
		"gameName": "cieszyn",
		"realName": "Cieszyn",
		"country": "poland",
		"x": "29295.3",
		"y": "128.898",
		"z": "6348.3"
	},
	{
		"gameName": "cluj",
		"realName": "Cluj-Napoca",
		"country": "romania",
		"x": "49554.8",
		"y": "120",
		"z": "20421.1"
	},
	{
		"gameName": "constanta",
		"realName": "Constanţa",
		"country": "romania",
		"x": "71837.5",
		"y": "120",
		"z": "32816.9"
	},
	{
		"gameName": "craiova",
		"realName": "Craiova",
		"country": "romania",
		"x": "52254.7",
		"y": "120",
		"z": "34444.2"
	},
	{
		"gameName": "croydon",
		"realName": "Croydon",
		"country": "uk",
		"x": "-39570.6",
		"y": "152.719",
		"z": "-10454.6"
	},
	{
		"gameName": "debrecen",
		"realName": "Debrecen",
		"country": "hungary",
		"x": "41641.6",
		"y": "123.836",
		"z": "17483.7"
	},
	{
		"gameName": "dijon",
		"realName": "Dijon",
		"country": "france",
		"x": "-22312",
		"y": "97.3984",
		"z": "16721.5"
	},
	{
		"gameName": "donestia",
		"realName": "San Sebastian/Donestia",
		"country": "spain",
		"x": "-53789.7",
		"y": "62.7109",
		"z": "34870.4"
	},
	{
		"gameName": "dover",
		"realName": "Dover",
		"country": "uk",
		"x": "-33321.9",
		"y": "99.3984",
		"z": "-7884.36"
	},
	{
		"gameName": "duisburg",
		"realName": "Duisburg",
		"country": "germany",
		"x": "-12913.6",
		"y": "50",
		"z": "-6170.93"
	},
	{
		"gameName": "esbjerg",
		"realName": "Esbjerg",
		"country": "denmark",
		"x": "-4699.43",
		"y": "69.6875",
		"z": "-27555.9"
	},
	{
		"gameName": "europoort",
		"realName": "Europoort",
		"country": "netherlands",
		"x": "-21791.1",
		"y": "78.5234",
		"z": "-8987.42"
	},
	{
		"gameName": "felixstowe",
		"realName": "Felixstowe",
		"country": "uk",
		"x": "-31664.6",
		"y": "101.398",
		"z": "-13837.2"
	},
	{
		"gameName": "flensburg",
		"realName": "Flensburg",
		"country": "germany",
		"x": "-780.336",
		"y": "50.293",
		"z": "-22997.3"
	},
	{
		"gameName": "frederikshv",
		"realName": "Frederikshavn",
		"country": "denmark",
		"x": "2711.7",
		"y": "46.6875",
		"z": "-38141.5"
	},
	{
		"gameName": "ftwilliam",
		"realName": "Fort William",
		"country": "uk",
		"x": "-50854.3",
		"y": "115.898",
		"z": "-56132.7"
	},
	{
		"gameName": "gavle",
		"realName": "Gävle",
		"country": "sweden",
		"x": "23069.2",
		"y": "64.2813",
		"z": "-55929.9"
	},
	{
		"gameName": "gdansk",
		"realName": "Gdańsk",
		"country": "poland",
		"x": "28343.1",
		"y": "91.2305",
		"z": "-20619.5"
	},
	{
		"gameName": "gdynia",
		"realName": "Gdynia",
		"country": "poland",
		"x": "28154.4",
		"y": "124.887",
		"z": "-22045.9"
	},
	{
		"gameName": "gedser",
		"realName": "Gedser",
		"country": "denmark",
		"x": "6271.11",
		"y": "52.3789",
		"z": "-22000.3"
	},
	{
		"gameName": "genova",
		"realName": "Genova",
		"country": "italy",
		"x": "-7493.95",
		"y": "102.129",
		"z": "35487.7"
	},
	{
		"gameName": "gorzow",
		"realName": "Gorzów Wlkp.",
		"country": "poland",
		"x": "17502.4",
		"y": "100.926",
		"z": "-11074.3"
	},
	{
		"gameName": "goteborg",
		"realName": "Göteborg",
		"country": "sweden",
		"x": "7235.89",
		"y": "73.875",
		"z": "-40227.5"
	},
	{
		"gameName": "grimsby",
		"realName": "Grimsby",
		"country": "uk",
		"x": "-36117.9",
		"y": "124.66",
		"z": "-26575.2"
	},
	{
		"gameName": "groedig",
		"realName": "Grödig",
		"country": "Austria",
		"x": "8008.66",
		"y": "103.914",
		"z": "16688.1"
	},
	{
		"gameName": "grudziadz",
		"realName": "Grudziądz",
		"country": "poland",
		"x": "31238",
		"y": "81.1992",
		"z": "-16550.4"
	},
	{
		"gameName": "hameenlinna",
		"realName": "Hämeenlinna",
		"country": "finland",
		"x": "42545.3",
		"y": "106.004",
		"z": "-59899.2"
	},
	{
		"gameName": "haparanda",
		"realName": "Haparanda",
		"country": "sweden",
		"x": "37318.5",
		"y": "99.9023",
		"z": "-86889.9"
	},
	{
		"gameName": "havre",
		"realName": "Le Havre",
		"country": "france",
		"x": "-38340.7",
		"y": "52",
		"z": "1479.85"
	},
	{
		"gameName": "helsingborg",
		"realName": "Helsingborg",
		"country": "sweden",
		"x": "9405.2",
		"y": "66.1016",
		"z": "-29882.4"
	},
	{
		"gameName": "helsinki",
		"realName": "Helsinki",
		"country": "finland",
		"x": "44357.5",
		"y": "137.906",
		"z": "-55531.1"
	},
	{
		"gameName": "herning",
		"realName": "Herning",
		"country": "denmark",
		"x": "-3455.63",
		"y": "50.0469",
		"z": "-30797"
	},
	{
		"gameName": "hirtshals",
		"realName": "Hirtshals",
		"country": "denmark",
		"x": "1425.47",
		"y": "54.4688",
		"z": "-38873.3"
	},
	{
		"gameName": "hofn",
		"realName": "Höfn",
		"country": "iceland",
		"x": "-73990.5",
		"y": "50",
		"z": "-88514.8"
	},
	{
		"gameName": "holmavik",
		"realName": "Hólmavík",
		"country": "iceland",
		"x": "-84765.7",
		"y": "77.4609",
		"z": "-106902"
	},
	{
		"gameName": "holstebro",
		"realName": "Holstebro",
		"country": "denmark",
		"x": "-3816.61",
		"y": "57.25",
		"z": "-32659.8"
	},
	{
		"gameName": "hull",
		"realName": "Hull",
		"country": "uk",
		"x": "-35543.9",
		"y": "121.809",
		"z": "-29239.1"
	},
	{
		"gameName": "ijmuiden",
		"realName": "IJmuiden",
		"country": "netherlands",
		"x": "-19700.3",
		"y": "75.3477",
		"z": "-12077.1"
	},
	{
		"gameName": "inverness",
		"realName": "Inverness",
		"country": "uk",
		"x": "-46444.2",
		"y": "115.898",
		"z": "-59141.8"
	},
	{
		"gameName": "irun",
		"realName": "Irun",
		"country": "spain",
		"x": "-52624.1",
		"y": "64.875",
		"z": "35167.4"
	},
	{
		"gameName": "joensuu",
		"realName": "Joensuu",
		"country": "finland",
		"x": "54766.7",
		"y": "112",
		"z": "-70556.7"
	},
	{
		"gameName": "jonkoping",
		"realName": "Jönköping",
		"country": "sweden",
		"x": "14177.3",
		"y": "70.543",
		"z": "-39575.6"
	},
	{
		"gameName": "jyvaskyla",
		"realName": "Jyväskylä",
		"country": "finland",
		"x": "44157.9",
		"y": "106.805",
		"z": "-67666.3"
	},
	{
		"gameName": "kalmar",
		"realName": "Kalmar",
		"country": "sweden",
		"x": "20559.5",
		"y": "70.3945",
		"z": "-33634.5"
	},
	{
		"gameName": "kaluga",
		"realName": "Kaluga",
		"country": "russia",
		"x": "86328.6",
		"y": "67.8984",
		"z": "-31348.2"
	},
	{
		"gameName": "karlskrona",
		"realName": "Karlskrona",
		"country": "sweden",
		"x": "17145.6",
		"y": "46.6875",
		"z": "-30862.4"
	},
	{
		"gameName": "karlstad",
		"realName": "Karlstad",
		"country": "sweden",
		"x": "12989.8",
		"y": "60.5",
		"z": "-48643.2"
	},
	{
		"gameName": "karsamaki",
		"realName": "Kärsämäki",
		"country": "finland",
		"x": "43370.3",
		"y": "100.133",
		"z": "-77032.8"
	},
	{
		"gameName": "katowice",
		"realName": "Katowice",
		"country": "poland",
		"x": "30728.8",
		"y": "144.246",
		"z": "2458.83"
	},
	{
		"gameName": "kaunas",
		"realName": "Kaunas",
		"country": "lithuania",
		"x": "45413.9",
		"y": "104",
		"z": "-24878.1"
	},
	{
		"gameName": "keflavik",
		"realName": "Keflavík Airport",
		"country": "iceland",
		"x": "-94118.3",
		"y": "57.3203",
		"z": "-98004"
	},
	{
		"gameName": "kemi",
		"realName": "Kemi",
		"country": "finland",
		"x": "40102.5",
		"y": "105.012",
		"z": "-85560.6"
	},
	{
		"gameName": "kholm",
		"realName": "Kholm",
		"country": "russia",
		"x": "67228.7",
		"y": "57.25",
		"z": "-42842.4"
	},
	{
		"gameName": "kielce",
		"realName": "Kielce",
		"country": "poland",
		"x": "36896.1",
		"y": "116.113",
		"z": "-1011.63"
	},
	{
		"gameName": "klagenfurt",
		"realName": "Klagenfurt am Wörthersee",
		"country": "austria",
		"x": "14001.3",
		"y": "49.6523",
		"z": "23027.6"
	},
	{
		"gameName": "klaksvik",
		"realName": "Klaksvík",
		"country": "faroe",
		"x": "-49964",
		"y": "59.8984",
		"z": "-83155.7"
	},
	{
		"gameName": "klin",
		"realName": "Klin",
		"country": "russia",
		"x": "84401.6",
		"y": "57.4492",
		"z": "-42236.8"
	},
	{
		"gameName": "kobenhavn",
		"realName": "København",
		"country": "denmark",
		"x": "8100.74",
		"y": "58.7266",
		"z": "-28097.8"
	},
	{
		"gameName": "kosice",
		"realName": "Košice",
		"country": "slovakia",
		"x": "39843.9",
		"y": "90",
		"z": "10494.4"
	},
	{
		"gameName": "koszalin",
		"realName": "Koszalin",
		"country": "poland",
		"x": "20313.1",
		"y": "125.449",
		"z": "-19445.3"
	},
	{
		"gameName": "krafla",
		"realName": "Krafla",
		"country": "iceland",
		"x": "-72508.4",
		"y": "96.1875",
		"z": "-99684.3"
	},
	{
		"gameName": "krakow",
		"realName": "Kraków",
		"country": "poland",
		"x": "34470.3",
		"y": "144.246",
		"z": "3249.68"
	},
	{
		"gameName": "kristiansand",
		"realName": "Kristiansand",
		"country": "norway",
		"x": "-4638.28",
		"y": "58",
		"z": "-42891.5"
	},
	{
		"gameName": "kristianstad",
		"realName": "Kristianstad",
		"country": "sweden",
		"x": "13704.1",
		"y": "55.0781",
		"z": "-29967.9"
	},
	{
		"gameName": "krosno",
		"realName": "Krosno",
		"country": "poland",
		"x": "40842.8",
		"y": "176.02",
		"z": "4645.48"
	},
	{
		"gameName": "kuopio",
		"realName": "Kuopio",
		"country": "finland",
		"x": "48984.6",
		"y": "106.898",
		"z": "-72219.8"
	},
	{
		"gameName": "kursk",
		"realName": "Kursk",
		"country": "russia",
		"x": "91396.1",
		"y": "74.1797",
		"z": "-16073.8"
	},
	{
		"gameName": "lahti",
		"realName": "Lahti",
		"country": "finland",
		"x": "45112.6",
		"y": "104.199",
		"z": "-60580.5"
	},
	{
		"gameName": "liege",
		"realName": "Liège",
		"country": "belgium",
		"x": "-17181.5",
		"y": "108.012",
		"z": "-1231.25"
	},
	{
		"gameName": "lille",
		"realName": "Lille",
		"country": "france",
		"x": "-26495.9",
		"y": "92.6211",
		"z": "-2483.4"
	},
	{
		"gameName": "limoges",
		"realName": "Limoges",
		"country": "france",
		"x": "-38531.9",
		"y": "97.4023",
		"z": "22567.9"
	},
	{
		"gameName": "linkoping",
		"realName": "Linköping",
		"country": "sweden",
		"x": "18586.1",
		"y": "61",
		"z": "-43325.2"
	},
	{
		"gameName": "ljubljana",
		"realName": "Ljubljana",
		"country": "slovenia",
		"x": "14709.9",
		"y": "96.9883",
		"z": "26484"
	},
	{
		"gameName": "lodz",
		"realName": "Łódź",
		"country": "poland",
		"x": "32014.5",
		"y": "60",
		"z": "-6143.92"
	},
	{
		"gameName": "lorient",
		"realName": "Lorient",
		"country": "france",
		"x": "-54828.6",
		"y": "62",
		"z": "8687.19"
	},
	{
		"gameName": "lublin",
		"realName": "Lublin",
		"country": "poland",
		"x": "42859.6",
		"y": "123",
		"z": "-3967.52"
	},
	{
		"gameName": "luga",
		"realName": "Luga",
		"country": "russia",
		"x": "59757.7",
		"y": "91.0195",
		"z": "-50098.2"
	},
	{
		"gameName": "luki",
		"realName": "Velikiye Luki",
		"country": "russia",
		"x": "65110.6",
		"y": "47.0703",
		"z": "-37441.8"
	},
	{
		"gameName": "lutsk",
		"realName": "Луцьк (Lutsk)",
		"country": "ukraine",
		"x": "59477.4",
		"y": "55.1211",
		"z": "-16285.8"
	},
	{
		"gameName": "luxembourg",
		"realName": "Luxembourg",
		"country": "luxembourg",
		"x": "-16134.2",
		"y": "152.621",
		"z": "4382.97"
	},
	{
		"gameName": "lyon",
		"realName": "Lyon",
		"country": "france",
		"x": "-23869.8",
		"y": "139.359",
		"z": "25892.3"
	},
	{
		"gameName": "mans",
		"realName": "Le Mans",
		"country": "france",
		"x": "-40038.6",
		"y": "76",
		"z": "10523.9"
	},
	{
		"gameName": "maribor",
		"realName": "Maribor",
		"country": "slovenia",
		"x": "18319.2",
		"y": "79.1992",
		"z": "24176.3"
	},
	{
		"gameName": "metz",
		"realName": "Metz",
		"country": "france",
		"x": "-16294.5",
		"y": "104.516",
		"z": "7463.71"
	},
	{
		"gameName": "mikkeli",
		"realName": "Mikkeli",
		"country": "finland",
		"x": "49304.6",
		"y": "111.875",
		"z": "-65111"
	},
	{
		"gameName": "minsk",
		"realName": "Minsk",
		"country": "belarus",
		"x": "58358.6",
		"y": "31.0117",
		"z": "-22095.2"
	},
	{
		"gameName": "modena",
		"realName": "Modena",
		"country": "italy",
		"x": "662.281",
		"y": "82.9961",
		"z": "34036.3"
	},
	{
		"gameName": "mogilev",
		"realName": "Mahilyow",
		"country": "belarus",
		"x": "67307.6",
		"y": "39.5039",
		"z": "-23216.2"
	},
	{
		"gameName": "moscow",
		"realName": "Moscow",
		"country": "russia",
		"x": "88533.5",
		"y": "46.5",
		"z": "-39575.5"
	},
	{
		"gameName": "mozir",
		"realName": "Mazyr",
		"country": "belarus",
		"x": "65983",
		"y": "53.5898",
		"z": "-12548.9"
	},
	{
		"gameName": "mstislavl",
		"realName": "Mstsislaw",
		"country": "belarus",
		"x": "71206.8",
		"y": "65.4023",
		"z": "-26136.8"
	},
	{
		"gameName": "mukacheve",
		"realName": "Мукачеве (Mukacheve)",
		"country": "ukraine",
		"x": "45497.1",
		"y": "124.898",
		"z": "11834.6"
	},
	{
		"gameName": "nantes",
		"realName": "Nantes",
		"country": "france",
		"x": "-47921.5",
		"y": "54",
		"z": "13123.5"
	},
	{
		"gameName": "napapiiri",
		"realName": "Napapiiri",
		"country": "finland",
		"x": "41580.4",
		"y": "120",
		"z": "-92240.3"
	},
	{
		"gameName": "narva",
		"realName": "Narva",
		"country": "estonia",
		"x": "54064.4",
		"y": "68.1758",
		"z": "-52405.2"
	},
	{
		"gameName": "nevel",
		"realName": "Nevel",
		"country": "russia",
		"x": "63689.5",
		"y": "44.1406",
		"z": "-35678.8"
	},
	{
		"gameName": "novgorod",
		"realName": "Veliky Novgorod",
		"country": "russia",
		"x": "65052.4",
		"y": "85.5625",
		"z": "-49111.5"
	},
	{
		"gameName": "nowogard",
		"realName": "Nowogard",
		"country": "poland",
		"x": "17888.8",
		"y": "98.0313",
		"z": "-16557.9"
	},
	{
		"gameName": "nynashamn",
		"realName": "Nynäshamn",
		"country": "sweden",
		"x": "26448.2",
		"y": "62.6484",
		"z": "-46165.7"
	},
	{
		"gameName": "oban",
		"realName": "Oban",
		"country": "uk",
		"x": "-53420.4",
		"y": "111.898",
		"z": "-53500.1"
	},
	{
		"gameName": "oberhausen",
		"realName": "Oberhausen",
		"country": "germany",
		"x": "-11793.2",
		"y": "93.957",
		"z": "-5322.95"
	},
	{
		"gameName": "obninsk",
		"realName": "Obninsk",
		"country": "russia",
		"x": "85332.9",
		"y": "66.6289",
		"z": "-35073.1"
	},
	{
		"gameName": "odense",
		"realName": "Odense",
		"country": "denmark",
		"x": "1617.69",
		"y": "69.9023",
		"z": "-26700.4"
	},
	{
		"gameName": "olsztyn",
		"realName": "Olsztyn",
		"country": "poland",
		"x": "34758.6",
		"y": "92.1094",
		"z": "-17885.9"
	},
	{
		"gameName": "opole",
		"realName": "Opole",
		"country": "poland",
		"x": "27536.9",
		"y": "139.586",
		"z": "-679.391"
	},
	{
		"gameName": "oradea",
		"realName": "Oradea",
		"country": "romania",
		"x": "43493.9",
		"y": "120",
		"z": "19439.1"
	},
	{
		"gameName": "orebro",
		"realName": "Örebro",
		"country": "sweden",
		"x": "17087.8",
		"y": "62",
		"z": "-48374.7"
	},
	{
		"gameName": "orel",
		"realName": "Orel",
		"country": "russia",
		"x": "87658.2",
		"y": "61.8633",
		"z": "-23228"
	},
	{
		"gameName": "orlea",
		"realName": "Orléans",
		"country": "france",
		"x": "-33526.4",
		"y": "78.9414",
		"z": "11781.6"
	},
	{
		"gameName": "orsha",
		"realName": "Orsha",
		"country": "belarus",
		"x": "67891.2",
		"y": "40.5039",
		"z": "-26320.7"
	},
	{
		"gameName": "oslo",
		"realName": "Oslo",
		"country": "norway",
		"x": "4390.91",
		"y": "52.5117",
		"z": "-53410.5"
	},
	{
		"gameName": "ostashkov",
		"realName": "Ostashkov",
		"country": "russia",
		"x": "71691.7",
		"y": "67.3633",
		"z": "-44016.8"
	},
	{
		"gameName": "ostrava",
		"realName": "Ostrava",
		"country": "czech",
		"x": "28231.9",
		"y": "125.836",
		"z": "5136.1"
	},
	{
		"gameName": "ostroleka",
		"realName": "Ostrołęka",
		"country": "poland",
		"x": "38890.4",
		"y": "95.2539",
		"z": "-14259.3"
	},
	{
		"gameName": "oulu",
		"realName": "Oulu",
		"country": "finland",
		"x": "40906.9",
		"y": "98",
		"z": "-81971.1"
	},
	{
		"gameName": "padborg",
		"realName": "Padborg",
		"country": "denmark",
		"x": "-1608.62",
		"y": "55.5469",
		"z": "-24340.2"
	},
	{
		"gameName": "panevezys",
		"realName": "Panevėžys",
		"country": "lithuania",
		"x": "46296.1",
		"y": "111.961",
		"z": "-30215.8"
	},
	{
		"gameName": "paris",
		"realName": "Paris",
		"country": "france",
		"x": "-30494.9",
		"y": "92.6211",
		"z": "6998.41"
	},
	{
		"gameName": "parma",
		"realName": "Parma",
		"country": "italy",
		"x": "-2194.13",
		"y": "81.6328",
		"z": "32558.9"
	},
	{
		"gameName": "parnu",
		"realName": "Pärnu",
		"country": "estonia",
		"x": "44787.3",
		"y": "74.5859",
		"z": "-44526.4"
	},
	{
		"gameName": "pau",
		"realName": "Pau",
		"country": "france",
		"x": "-47944.2",
		"y": "111.109",
		"z": "36082.7"
	},
	{
		"gameName": "pecs",
		"realName": "Pécs",
		"country": "Hungary",
		"x": "29039.9",
		"y": "74.6836",
		"z": "26311.6"
	},
	{
		"gameName": "peterburg",
		"realName": "Saint Petersburg",
		"country": "russia",
		"x": "60356.8",
		"y": "96.6836",
		"z": "-56936"
	},
	{
		"gameName": "piatra",
		"realName": "Piatra Neamţ",
		"country": "romania",
		"x": "59568.8",
		"y": "120",
		"z": "17749.3"
	},
	{
		"gameName": "pila",
		"realName": "Piła",
		"country": "poland",
		"x": "21276.1",
		"y": "86.2734",
		"z": "-14380.2"
	},
	{
		"gameName": "pinsk",
		"realName": "Pinsk",
		"country": "belarus",
		"x": "55678.1",
		"y": "62.3516",
		"z": "-10592.7"
	},
	{
		"gameName": "plock",
		"realName": "Płock",
		"country": "poland",
		"x": "32370.5",
		"y": "90.1992",
		"z": "-10795.9"
	},
	{
		"gameName": "plymouth",
		"realName": "Plymouth",
		"country": "uk",
		"x": "-60041.4",
		"y": "101.398",
		"z": "-7882.32"
	},
	{
		"gameName": "poitiers",
		"realName": "Poitiers",
		"country": "france",
		"x": "-41108",
		"y": "90.1406",
		"z": "18442.8"
	},
	{
		"gameName": "pori",
		"realName": "Pori",
		"country": "finland",
		"x": "34896.6",
		"y": "109.898",
		"z": "-61757.5"
	},
	{
		"gameName": "porkhov",
		"realName": "Porkhov",
		"country": "russia",
		"x": "60948.5",
		"y": "72.5273",
		"z": "-44020.6"
	},
	{
		"gameName": "portsmouth",
		"realName": "Portsmouth",
		"country": "uk",
		"x": "-43034.2",
		"y": "121.809",
		"z": "-5752.09"
	},
	{
		"gameName": "porvoo",
		"realName": "Porvoo",
		"country": "finland",
		"x": "47431.8",
		"y": "107.949",
		"z": "-57017.7"
	},
	{
		"gameName": "przemysl",
		"realName": "Przemyśl",
		"country": "poland",
		"x": "44638.9",
		"y": "110.391",
		"z": "3969.67"
	},
	{
		"gameName": "pskov",
		"realName": "Pskov",
		"country": "russia",
		"x": "56542.8",
		"y": "71.1953",
		"z": "-43761.7"
	},
	{
		"gameName": "puttgarden",
		"realName": "Puttgarden",
		"country": "germany",
		"x": "4001.17",
		"y": "43.8906",
		"z": "-21612.7"
	},
	{
		"gameName": "radom",
		"realName": "Radom",
		"country": "poland",
		"x": "38543.6",
		"y": "115.695",
		"z": "-4837.94"
	},
	{
		"gameName": "reims",
		"realName": "Reims",
		"country": "france",
		"x": "-24021.9",
		"y": "96.3086",
		"z": "5799.34"
	},
	{
		"gameName": "renne",
		"realName": "Rennes",
		"country": "france",
		"x": "-48307.4",
		"y": "63.7969",
		"z": "8223.08"
	},
	{
		"gameName": "reydar",
		"realName": "Reyðarfjörður",
		"country": "iceland",
		"x": "-69235.1",
		"y": "50",
		"z": "-92368.9"
	},
	{
		"gameName": "reykjavik",
		"realName": "Reykjavík",
		"country": "iceland",
		"x": "-90723.9",
		"y": "57.3203",
		"z": "-98482.6"
	},
	{
		"gameName": "rgev",
		"realName": "Rzhev",
		"country": "russia",
		"x": "77040.4",
		"y": "36.4648",
		"z": "-39807.6"
	},
	{
		"gameName": "riga",
		"realName": "Rīga",
		"country": "latvia",
		"x": "44351.2",
		"y": "68.1758",
		"z": "-36490.8"
	},
	{
		"gameName": "rodbyhavn",
		"realName": "Rødbyhavn",
		"country": "denmark",
		"x": "4378.43",
		"y": "49.1719",
		"z": "-22326.5"
	},
	{
		"gameName": "roslavl",
		"realName": "Roslavl",
		"country": "russia",
		"x": "77169.5",
		"y": "61.0352",
		"z": "-25261.4"
	},
	{
		"gameName": "rouen",
		"realName": "Rouen",
		"country": "france",
		"x": "-34886.4",
		"y": "57",
		"z": "2583.58"
	},
	{
		"gameName": "rovaniemi",
		"realName": "Rovaniemi",
		"country": "finland",
		"x": "40795.2",
		"y": "104.375",
		"z": "-91202.9"
	},
	{
		"gameName": "ruse",
		"realName": "Русе (Ruse)",
		"country": "bulgaria",
		"x": "61661.9",
		"y": "120",
		"z": "36399.5"
	},
	{
		"gameName": "rzeszow",
		"realName": "Rzeszów",
		"country": "poland",
		"x": "42993.9",
		"y": "110.492",
		"z": "2919.09"
	},
	{
		"gameName": "sanok",
		"realName": "Sanok",
		"country": "poland",
		"x": "43027.8",
		"y": "153.367",
		"z": "5134.43"
	},
	{
		"gameName": "selfoss",
		"realName": "Selfoss",
		"country": "iceland",
		"x": "-89796.2",
		"y": "49.3047",
		"z": "-95809.1"
	},
	{
		"gameName": "seydis",
		"realName": "Seyðisfjörður",
		"country": "iceland",
		"x": "-68112.5",
		"y": "46.3789",
		"z": "-93717.5"
	},
	{
		"gameName": "shlisselburg",
		"realName": "Shlisselburg",
		"country": "russia",
		"x": "64110.6",
		"y": "113.523",
		"z": "-59343.8"
	},
	{
		"gameName": "sibiu",
		"realName": "Sibiu",
		"country": "romania",
		"x": "52251.6",
		"y": "132.074",
		"z": "26325.7"
	},
	{
		"gameName": "sluck",
		"realName": "Slutsk",
		"country": "belarus",
		"x": "59477.4",
		"y": "55.1211",
		"z": "-16285.8"
	},
	{
		"gameName": "smolensk",
		"realName": "Smolensk",
		"country": "russia",
		"x": "73118.6",
		"y": "34.2422",
		"z": "-29374.4"
	},
	{
		"gameName": "soderhamn",
		"realName": "Söderhamn",
		"country": "sweden",
		"x": "21956.2",
		"y": "84.3828",
		"z": "-59633.3"
	},
	{
		"gameName": "sodertalje",
		"realName": "Södertälje",
		"country": "sweden",
		"x": "23525.2",
		"y": "50.9922",
		"z": "-46319.9"
	},
	{
		"gameName": "stavanger",
		"realName": "Stavanger",
		"country": "norway",
		"x": "-10553.7",
		"y": "62.6094",
		"z": "-48126.8"
	},
	{
		"gameName": "stockholm",
		"realName": "Stockholm",
		"country": "sweden",
		"x": "24747.3",
		"y": "68.7656",
		"z": "-47131.9"
	},
	{
		"gameName": "strasbourg",
		"realName": "Strasbourg",
		"country": "france",
		"x": "-10786.9",
		"y": "100",
		"z": "11198.7"
	},
	{
		"gameName": "sundsvall",
		"realName": "Sundsvall",
		"country": "sweden",
		"x": "21950.3",
		"y": "84",
		"z": "-65749.8"
	},
	{
		"gameName": "suwalki",
		"realName": "Suwałki",
		"country": "poland",
		"x": "43448.6",
		"y": "118.813",
		"z": "-21045.2"
	},
	{
		"gameName": "swansea",
		"realName": "Swansea",
		"country": "uk",
		"x": "-56896",
		"y": "71.3984",
		"z": "-16881.9"
	},
	{
		"gameName": "swinoujscie",
		"realName": "Świnoujście",
		"country": "poland",
		"x": "13488.7",
		"y": "145.68",
		"z": "-17184.3"
	},
	{
		"gameName": "szeged",
		"realName": "Szeged",
		"country": "hungary",
		"x": "36880.7",
		"y": "74.0469",
		"z": "24565.7"
	},
	{
		"gameName": "szczecin",
		"realName": "Szczecin",
		"country": "poland",
		"x": "14764.7",
		"y": "96.5508",
		"z": "-15366.7"
	},
	{
		"gameName": "tallinn",
		"realName": "Tallinn",
		"country": "estonia",
		"x": "44770.9",
		"y": "78.0703",
		"z": "-50731.6"
	},
	{
		"gameName": "tampere",
		"realName": "Tampere",
		"country": "finland",
		"x": "40069.1",
		"y": "137.168",
		"z": "-62656.5"
	},
	{
		"gameName": "tartu",
		"realName": "Tartu",
		"country": "estonia",
		"x": "51198.6",
		"y": "72.8086",
		"z": "-46116.1"
	},
	{
		"gameName": "thurso",
		"realName": "Thurso",
		"country": "uk",
		"x": "-41731.6",
		"y": "111.898",
		"z": "-66122.4"
	},
	{
		"gameName": "timisoara",
		"realName": "Timişoara",
		"country": "romania",
		"x": "40392.8",
		"y": "123.617",
		"z": "27328.8"
	},
	{
		"gameName": "tornio",
		"realName": "Tornio",
		"country": "finland",
		"x": "37743.5",
		"y": "99.9023",
		"z": "-86984.2"
	},
	{
		"gameName": "torshavn",
		"realName": "Tórshavn",
		"country": "faroe",
		"x": "-51298.5",
		"y": "59.8984",
		"z": "-81483.6"
	},
	{
		"gameName": "toulouse",
		"realName": "Toulouse",
		"country": "france",
		"x": "-39911.4",
		"y": "65",
		"z": "34605.3"
	},
	{
		"gameName": "tours",
		"realName": "Tours",
		"country": "france",
		"x": "-38487.6",
		"y": "75.3633",
		"z": "14301.3"
	},
	{
		"gameName": "trelleborg",
		"realName": "Trelleborg",
		"country": "sweden",
		"x": "10808.3",
		"y": "55.3242",
		"z": "-25887"
	},
	{
		"gameName": "tula",
		"realName": "Tula",
		"country": "russia",
		"x": "91217.5",
		"y": "17.1016",
		"z": "-32713.7"
	},
	{
		"gameName": "turku",
		"realName": "Turku",
		"country": "finland",
		"x": "36549",
		"y": "110.398",
		"z": "-56133.1"
	},
	{
		"gameName": "tver",
		"realName": "Tver",
		"country": "russia",
		"x": "81110.4",
		"y": "39.7695",
		"z": "-43874.4"
	},
	{
		"gameName": "ulm",
		"realName": "Ulm",
		"country": "germany",
		"x": "-2928.57",
		"y": "88.75",
		"z": "12657"
	},
	{
		"gameName": "uppsala",
		"realName": "Uppsala",
		"country": "sweden",
		"x": "24021.5",
		"y": "77.4219",
		"z": "-51634.5"
	},
	{
		"gameName": "uzhhorod",
		"realName": "Ужгород (Uzhhorod)",
		"country": "ukraine",
		"x": "43781",
		"y": "124.5",
		"z": "11200.1"
	},
	{
		"gameName": "vaduz",
		"realName": "Vaduz",
		"country": "liecht",
		"x": "-3865.21",
		"y": "93.3555",
		"z": "18906.6"
	},
	{
		"gameName": "valday",
		"realName": "Valday",
		"country": "russia",
		"x": "70492.6",
		"y": "100.309",
		"z": "-49050"
	},
	{
		"gameName": "valga",
		"realName": "Valga",
		"country": "estonia",
		"x": "49770.1",
		"y": "68.3086",
		"z": "-42978.1"
	},
	{
		"gameName": "valka",
		"realName": "Valka",
		"country": "latvia",
		"x": "49463.9",
		"y": "68.3086",
		"z": "-42752.1"
	},
	{
		"gameName": "vantaa",
		"realName": "Vantaa",
		"country": "finland",
		"x": "45004.3",
		"y": "117.699",
		"z": "-56661.7"
	},
	{
		"gameName": "varkaus",
		"realName": "Varkaus",
		"country": "finland",
		"x": "50510.6",
		"y": "112.898",
		"z": "-68975.5"
	},
	{
		"gameName": "vasteraas",
		"realName": "Västerås",
		"country": "sweden",
		"x": "20937.7",
		"y": "62.0859",
		"z": "-50468.3"
	},
	{
		"gameName": "vaxjo",
		"realName": "Växjö",
		"country": "sweden",
		"x": "16044.4",
		"y": "82.3125",
		"z": "-34835.6"
	},
	{
		"gameName": "velig",
		"realName": "Velizh",
		"country": "russia",
		"x": "68466.5",
		"y": "38.4023",
		"z": "-34541.6"
	},
	{
		"gameName": "venezia",
		"realName": "Venezia",
		"country": "italy",
		"x": "5089.88",
		"y": "77.8789",
		"z": "30078.9"
	},
	{
		"gameName": "ventspils",
		"realName": "Ventspils",
		"country": "latvia",
		"x": "36547.4",
		"y": "59.9883",
		"z": "-37959.7"
	},
	{
		"gameName": "verona",
		"realName": "Verona",
		"country": "italy",
		"x": "39.1094",
		"y": "78.4023",
		"z": "29453.3"
	},
	{
		"gameName": "viborg",
		"realName": "Viborg",
		"country": "denmark",
		"x": "-1033.26",
		"y": "57.7188",
		"z": "-33233.7"
	},
	{
		"gameName": "vicenza",
		"realName": "Vicenza",
		"country": "italy",
		"x": "3032.82",
		"y": "75.1328",
		"z": "29533.5"
	},
	{
		"gameName": "viitasaari",
		"realName": "Viitasaari",
		"country": "finland",
		"x": "44214.6",
		"y": "109.898",
		"z": "-72353.1"
	},
	{
		"gameName": "vik",
		"realName": "Vík",
		"country": "iceland",
		"x": "-86702.3",
		"y": "65.4219",
		"z": "-89729.3"
	},
	{
		"gameName": "vitebsk",
		"realName": "Vitebsk",
		"country": "belarus",
		"x": "65443.4",
		"y": "57.4766",
		"z": "-32173.2"
	},
	{
		"gameName": "volochyok",
		"realName": "Vyshny Volochyok",
		"country": "russia",
		"x": "75473.5",
		"y": "75.5391",
		"z": "-46654.9"
	},
	{
		"gameName": "volokolamsk",
		"realName": "Volokolamsk",
		"country": "russia",
		"x": "82679.4",
		"y": "70.2461",
		"z": "-40014.5"
	},
	{
		"gameName": "voronezh",
		"realName": "Voronezh",
		"country": "russia",
		"x": "102488",
		"y": "93.0898",
		"z": "-19897.4"
	},
	{
		"gameName": "vyazma",
		"realName": "Vyazma",
		"country": "russia",
		"x": "78418.8",
		"y": "43.2266",
		"z": "-33964.8"
	},
	{
		"gameName": "vyborg",
		"realName": "Vyborg",
		"country": "russia",
		"x": "55014",
		"y": "101.477",
		"z": "-59566.4"
	},
	{
		"gameName": "warszawa",
		"realName": "Warszawa",
		"country": "poland",
		"x": "37353.6",
		"y": "93.1836",
		"z": "-9467.43"
	},
	{
		"gameName": "wick",
		"realName": "Wick",
		"country": "uk",
		"x": "-39662.3",
		"y": "112.898",
		"z": "-64980.1"
	},
	{
		"gameName": "yukhnov",
		"realName": "Yukhnov",
		"country": "russia",
		"x": "80491.7",
		"y": "52.1523",
		"z": "-30929.9"
	},
	{
		"gameName": "zamosc",
		"realName": "Zamość",
		"country": "poland",
		"x": "46167.3",
		"y": "135.504",
		"z": "-1538.1"
	},
	{
		"gameName": "zwolle",
		"realName": "Zwolle",
		"country": "netherlands",
		"x": "-14526",
		"y": "105.766",
		"z": "-12292.1"
	}
]
